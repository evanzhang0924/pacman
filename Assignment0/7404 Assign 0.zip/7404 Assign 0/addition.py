"""
Run python autograder.py 
"""

def add(a, b):
    "Return the sum of a and b"
    "*** YOUR CODE HERE ***"
    print("Passed a=%s and b=%s, returning a+b=%s" % (a,b,a + b))
    return a + b
